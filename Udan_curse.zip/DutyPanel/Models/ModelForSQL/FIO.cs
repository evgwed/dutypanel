﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DutyPanel.Models.ModelForSQL
{
    //Класс для обработки SQL запросов ханимых процедур и функций
    public class FIO
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string SecondName { get; set; }
    }
}